export interface UpdateUserInfo {
  nickname: string;
}
export type CurrentView = 'userSummary';

class API {}

export const api = new API();
