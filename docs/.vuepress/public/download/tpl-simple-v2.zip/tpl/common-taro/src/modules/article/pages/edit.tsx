import {EluxPage} from '<%= elux %>';

definePageConfig({
  navigationBarTitleText: '编辑文章',
});

export default EluxPage;
