import {EluxPage} from '<%= elux %>';

definePageConfig({
  navigationBarTitleText: '文章列表',
});

export default EluxPage;
