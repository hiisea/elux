module.exports = {
  root: true,
  extends: ['plugin:@elux/<%= framework %>'],
  env: {
    browser: true,
    node: true,
  },
};
