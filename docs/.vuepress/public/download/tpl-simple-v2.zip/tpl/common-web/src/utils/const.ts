export const HomeUrl: string = '/article/list';
export const LoginUrl: string = '/stage/login';
